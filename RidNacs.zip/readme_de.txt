RidNacs
-------
Copyright Stephan Plath
http://www.splashsoft.de

RidNacs ist ein Programm zur Analyse des Speicherverbrauchs der Datentr�ger im Rechner. Es durchsucht einzelne Verzeichnisse, lokale oder Netzwerklaufwerke und stellt die Gr��e der Verzeichnisse �bersichtlich in einer Baumstruktur dar. 
Die Analyseergebnisse lassen sich in verschiedenen Formaten (XML-, HTML-, CSV-, Text-Datei) exportieren, so dass diese ausgedruckt oder mit sp�teren Analysen verglichen werden k�nnen.

Mit RidNacs kann der Anwender schnell erkennen, welche Verzeichnisse den meisten Speicherplatz belegen und f�r eine Bereinigung in Frage kommen. Neben der einfachen Handhabbarkeit zeichnet sich RidNacs durch seine hohe Analyse-Geschwindigkeit und den geringen Arbeitsspeicherverbrauch aus.

Danksagungen
------------
Die in RidNacs verwendeten Icons (Silk Icons) stammen von der Internetseite http://famfamfam.com. Sie sind frei nutzbar unter der Creative Commons Attribution 2.5 License (http://creativecommons.org/licenses/by/2.5/), wenn ein Verweis auf die genannte Lizenz und die Webseite des Autor erfolgt. 
