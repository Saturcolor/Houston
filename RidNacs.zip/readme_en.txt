RidNacs
-------
Copyright Stephan Plath
http://www.splashsoft.de

RidNacs is a very fast disk space usage analyzer for Microsoft Windows. It scans your local drives, network drives or single directories and produces a tree view with a percentage bar chart column. This gives the user a quick and easy way to identify the largest directories and it's very useful for cleaning up the disk. 
The result of the scan can be exported in different formats (XML, HTML, CSV, TXT), so it could be printed or compared with future scans. Besides of all these benefits RidNacs has an outstanding scan performance and it scores with a small memory footprint. 

Credits
-------
The icons used in RidNacs are from the Silk Icons set at http://famfamfam.com and are licensed under a Creative Commons Attribution 2.5 License (http://creativecommons.org/licenses/by/2.5/). 
